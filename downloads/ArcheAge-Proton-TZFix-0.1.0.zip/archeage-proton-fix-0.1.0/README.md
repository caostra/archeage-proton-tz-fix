# 아키에이지 크로니클 스팀덱 실행 오류 임시 해결 도구

**한국어** · [English](README.en.md)

[자동 패치 도구 v0.1.0 다운로드](https://github.com/caostra/archeage-proton-tz-fix/raw/refs/heads/main/downloads/ArcheAge-Proton-TZFix-0.1.0.zip)

아키에이지 크로니클 실행할 때 아래 오류가 뜨는 사람을 위한 **비공식·실험용 Proton 패치 도구**야.

> `SystemTimeToTzSpecificLocalTimeEx` 함수를 `KERNEL32.dll`에서 찾을 수 없다는 오류

스팀덱에서 **게임 모드 시작 화면까지 진입한 패치**를 적용해. 서버 접속, 실제 플레이, 장시간 안정성, 안티치트의 지속적인 허용 여부는 아직 확인하지 못했어.

## 먼저 확인할 것

- **검증한 특정 Proton Experimental 빌드만 지원해.** 이름이 같아도 업데이트 시점이 다르면 적용되지 않아.
- 지원하지 않는 버전이라고 나오면 중단해. 파일명이나 해시를 바꿔 강제로 적용하면 안 돼.
- 게임 전체를 복사하지 않아. **Proton만 별도로 복사하니까 약 1.5~2GiB 이상의 여유 공간**이 필요해. 도구가 원본 크기를 기준으로 여유 공간도 검사해.
- 원본 Proton, 게임 실행 파일, 안티치트 파일은 수정하지 않아.
- 정식 수정이 아니라 시간 변환 함수의 임시 우회야. 모든 시간대·서머타임 동작을 완전히 구현한 건 아니야.
- Python 3.9 이상과 GNU `cp`가 필요해. 관리자 권한이나 `sudo`, 추가 Python 패키지 설치는 필요 없어.

### 지원하는 원본 빌드

Proton의 `version` 파일 내용이 아래 값과 일치하고, DLL 해시도 검사를 통과해야 해.

```text
1793759737 experimental-bleeding-edge-11.0-464679-20261104-pa44208-w56e5a9-dcf0a0d-v15dd1e-x86_64
```

이 도구는 해당 빌드를 다운로드하거나 과거 버전으로 되돌려 주지 않아. **일반 Experimental이나 최신 bleeding-edge를 설치했다고 해서 지원되는 건 아니야.** 새 빌드는 별도 검증과 도구 업데이트가 필요해.

## 설치 방법

### 1. 압축 풀기

스팀덱을 **데스크톱 모드**로 전환하고, 위 링크에서 받은 ZIP을 압축 해제해.

`archeage_proton_fix.py`가 있는 폴더에서 터미널을 열어. 파일 관리자에서 폴더를 우클릭하면 **터미널 열기**를 사용할 수 있어. `patch.json`은 스크립트와 같은 폴더에 있어야 해.

### 2. 지원 여부 확인

```bash
python3 archeage_proton_fix.py check
```

이 단계에서는 파일을 변경하지 않아. **지원하는 버전과 DLL이라는 안내가 나왔을 때만** 다음 단계로 넘어가.

### 3. 패치 도구 설치

```bash
python3 archeage_proton_fix.py install
```

표시되는 원본·복사본 경로와 용량을 확인하고, 진행하려면 `y`를 입력해.

도구가 Proton만 임시 폴더에 복사하고 백업·패치·결과 검증까지 진행해. 검증을 통과하면 별도 Steam 호환 도구로 등록해. 게임과 기존 게임 프리픽스는 복사하지 않고, 같은 이름의 설치 폴더가 있으면 덮어쓰지 않아.

### 4. 게임 모드에서 선택

Steam을 완전히 재시작하거나 스팀덱을 재부팅한 뒤 아래처럼 설정해.

1. **게임 모드 → 아키에이지 크로니클**
2. **톱니바퀴 → 속성 → 호환성**
3. **특정 Steam Play 호환 도구 강제 사용** 켜기
4. **Proton Experimental (ArcheAge TZ Fix 20261104)** 선택
5. 기존 라이브러리에서 **플레이**

별도 게임을 추가하거나 데스크톱 실행 아이콘을 만들 필요는 없어. 첫 실행에는 셰이더 준비가 오래 걸릴 수 있어.

도구가 Steam 설정을 직접 바꾸거나 Steam을 자동 종료하지는 않아. 위의 호환 도구 선택은 직접 해 줘. 계정 등록·이용약관·개인정보 동의 화면이 나오면 내용을 읽고 직접 결정하면 돼.

## 설치 상태 확인

압축을 풀었던 폴더에서 실행해.

```bash
python3 archeage_proton_fix.py status
```

설치된 패치 DLL과 백업의 해시를 검사해.

## 되돌리기·제거

패치 사용을 중단하려면 게임을 종료하고, **게임 속성 → 호환성**에서 기존 Proton을 선택하면 돼. 기존 Proton에서는 원래 DLL 오류가 다시 발생할 수 있어.

패치 Proton 폴더도 지우려면 다른 Proton을 선택한 다음 **Steam을 완전히 종료**하고 실행해.

```bash
python3 archeage_proton_fix.py remove
```

이 도구가 만든 Proton 복사본만 제거해. 원본 Proton이나 게임·저장 데이터는 삭제하지 않아. Steam이 실행 중이거나 설정에 이 도구가 남아 있거나 파일 검증에 실패하면 자동 제거를 거부해.

## 경로가 다른 경우

기본적으로 `~/.local/share/Steam`, `~/.steam/steam`, `~/.steam/root`를 찾아. 자동으로 찾지 못하면 실제 경로를 지정해.

```bash
python3 archeage_proton_fix.py check --steam-root "/실제/Steam" --source "/실제/Proton - Experimental"
python3 archeage_proton_fix.py install --steam-root "/실제/Steam" --source "/실제/Proton - Experimental"
```

`--steam-root`는 `steamapps`가 들어 있는 Steam 설치 경로야. 커스텀 도구 폴더 자체의 심볼릭 링크는 지원하지 않아. Flatpak·다른 배포판의 경로와 실행은 별도로 검증하지 못했어.

## 문제가 생기면

- **버전 불일치:** 지원하지 않는 빌드야. 강제로 적용하지 마.
- **호환 도구 목록에 없음:** Steam을 완전히 종료하고 다시 실행하거나 재부팅해 봐.
- **이미 설치되어 있음:** `status`로 확인해. 기존 폴더를 임의로 덮어쓰지 마.
- **제거가 거부됨:** 다른 Proton을 선택했고 Steam과 게임을 모두 종료했는지 확인해.
- **DLL 오류 이후 다른 문제가 발생함:** 이 도구가 게임의 모든 호환성 문제를 해결하는 건 아니야.

문제를 공유할 때는 SteamOS 버전, `check` 결과, 오류 문구, 어느 화면까지 진행됐는지 알려 줘. 비밀번호나 계정 정보는 보내지 마. 로그를 공개할 때는 개인 정보가 들어 있는지도 확인해.

별도로 복사한 Proton은 Steam의 Experimental 업데이트를 자동으로 따라가지 않아.

## 패키지 구성과 검증

- `archeage_proton_fix.py`: 설치·검증·제거 코드
- `patch.json`: 검증한 DLL의 변경 부분과 해시. 완성 DLL이나 전체 Proton은 아니야.
- `SHA256SUMS.txt`: 패키지 파일별 체크섬
- [검증 기록](TESTING.md) · [출처와 라이선스 범위](NOTICE.md) · [코드 라이선스](LICENSE.txt)

개인 로그, IP 주소, 계정 정보, SSH 키, 게임 파일은 포함하지 않았어. 파일 해시는 디지털 서명이나 배포자 신원 보증은 아니니까, 신뢰할 수 있는 배포처인지 확인해.

이 도구는 Valve, Wine, 게임 개발사·퍼블리셔가 제공하거나 보증하는 공식 도구가 아니야.
